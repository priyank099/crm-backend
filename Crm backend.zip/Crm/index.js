var express=require("express");
var bodyParser=require('body-parser');
var app = express();

var Customer=require('./Api/customer');
var Lead=require('./Api/lead');
var Orderlist=require('./Api/orderlist');
var Employees=require('./Api/employees');
var Login=require('./Api/login');
var Auth=require('./Api/auth');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.use('/api',Customer);
app.use('/api',Lead);
app.use('/api',Orderlist);
app.use('/api',Employees);
app.use('/api',Login);
app.use('/api',Auth);

app.listen(5000);